﻿using assignmentDBfirst.Context;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace assignmentDBfirst.Controllers
{
    public class EmployeeController : Controller
    {

        private userEntities database;
        public EmployeeController()
        {
            this.database = new userEntities();
        }

        // GET: Employee
        public ActionResult Index()
        {
            var employee = database.Employees.ToList();
            return View(employee);
        }



        [HttpGet]
        public ActionResult Employee(Employee e)
        {
            if (e.Id > 0)
                return View(e);
            else
            {
                ModelState.Clear();
                //ViewBag.NoData = 0;
                return View();
            }

        }

        [HttpPost]
        public ActionResult AddEmployee(Employee emp)
        {
            ModelState.Remove("Id");
            if (ModelState.IsValid)
            {

                if (emp.Id <= 0)
                {
                    database.Employees.Add(emp);
                    database.SaveChanges();
                    TempData["Msg"] = "Employee information added successfully";
                }
                else
                {
                    database.Entry(emp).State = EntityState.Modified;
                    database.SaveChanges();
                    TempData["Msg"] = "Employee information modified successfully";
                }

                return RedirectToAction("Index");


                
            }

            //var departments = database.departments.ToList();
            //ViewBag.departments = new SelectList(departments, "DepartmentId", "Departmentname");
            return View("Employee");
        }

        public ActionResult Delete(int id)
        {
            var data = database.Employees.Where(x => x.Id == id).First();
            database.Employees.Remove(data);
            database.SaveChanges();
            //TempData["MsgRem"] = "Employee information removed successfully";

            return RedirectToAction("Index");
        }
    }
}