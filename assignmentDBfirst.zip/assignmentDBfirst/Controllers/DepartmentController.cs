﻿using assignmentDBfirst.Context;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace assignmentDBfirst.Controllers
{
    public class DepartmentController : Controller
    {
        private userEntities database;
        public DepartmentController()
        {
            this.database = new userEntities();
        }

        // GET: Department
        public ActionResult Index()
        {
            var dep = database.departments.ToList();
            return View(dep);
        }

        [HttpGet]
        public ActionResult Department(department d)
        {
            if (d.DepId > 0)
                return View(d);
            else
            {
                ModelState.Clear();
                return View();
            }

        }

        [HttpPost]
        public ActionResult AddDepartment(department dep)
        {
            ModelState.Remove("DepId");
            if (ModelState.IsValid)
            {

                if (dep.DepId <= 0)
                {
                    database.departments.Add(dep);
                    database.SaveChanges();
                    TempData["Msg"] = "Department added successfully";
                }
                else
                {
                    database.Entry(dep).State = EntityState.Modified;
                    database.SaveChanges();
                    TempData["Msg"] = "Department modified successfully";
                }

                return RedirectToAction("Index");



            }


            return View("Department");
        }

        public ActionResult Delete(int id)
        {
            var data = database.departments.Where(x => x.DepId == id).First();
            database.departments.Remove(data);
            database.SaveChanges();
            //TempData["MsgRem"] = "Department removed successfully";

            return RedirectToAction("Index");
        }
    }
}