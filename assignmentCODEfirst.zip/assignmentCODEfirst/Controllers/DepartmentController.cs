﻿using assignmentCODEfirst.Context;
using assignmentCODEfirst.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace assignmentCODEfirst.Controllers
{
    public class DepartmentController : Controller
    {
        private AppDB database;
        public DepartmentController()
        {
            this.database = new AppDB();
        }

        // GET: Department
        public ActionResult Index()
        {
            var dep = database.Departments.ToList();
            return View(dep);
        }

        [HttpGet]
        public ActionResult Department(Department d)
        {
            if (d.DepId > 0)
                return View(d);
            else
            {
                ModelState.Clear();
                return View();
            }
        }

        [HttpPost]
        public ActionResult AddDepartment(Department dep)
        {
            ModelState.Remove("DepId");
            if (ModelState.IsValid)
            {

                if (dep.DepId <= 0)
                {
                    database.Departments.Add(dep);
                    database.SaveChanges();
                    TempData["Msg"] = "Department added successfully";
                }
                else
                {
                    database.Entry(dep).State = EntityState.Modified;
                    database.SaveChanges();
                    TempData["Msg"] = "Department modified successfully";
                }

                return RedirectToAction("Index");



            }


            return View("Department");
        }

        public ActionResult Delete(int id)
        {
            var data = database.Departments.Where(x => x.DepId == id).First();
            database.Departments.Remove(data);
            database.SaveChanges();
            //TempData["MsgRem"] = "Department removed successfully";

            return RedirectToAction("Index");
        }
    }
}