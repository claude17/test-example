﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace assignmentCODEfirst.Models
{
    public class Employee
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayName("Joining Date")]
        public string JoinDate { get; set; }
        [Required]
        public double Salary { get; set; }
        public int DepId { get; set; }

        public virtual Department department { get; set; }
    }
}