﻿namespace assignmentCODEfirst.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Departments",
                c => new
                    {
                        DepId = c.Int(nullable: false, identity: true),
                        DepName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.DepId);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        JoinDate = c.String(nullable: false),
                        Salary = c.Double(nullable: false),
                        DepId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Departments", t => t.DepId, cascadeDelete: true)
                .Index(t => t.DepId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Employees", "DepId", "dbo.Departments");
            DropIndex("dbo.Employees", new[] { "DepId" });
            DropTable("dbo.Employees");
            DropTable("dbo.Departments");
        }
    }
}
